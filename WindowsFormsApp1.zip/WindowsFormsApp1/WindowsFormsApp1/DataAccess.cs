﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace WindowsFormsApp1
{
    public class BaseDataAccess
    {
        private const string DataSection = "dataConfiguration;";
        private readonly int _commandTimeout;
        protected readonly Database _db;

        public BaseDataAccess(string dbName)
        {
            _commandTimeout = 60;
            _db = new DatabaseProviderFactory(conn => GetConnectionString()).Create(dbName);
        }

        private static ConfigurationSection GetConnectionString()
        {
            return (ConfigurationSection)ConfigurationManager.GetSection(DataSection);
        }

        public IDataReader ExecuteReader(string proc, params object[] cmdParms)
        {
            var cmd = _db.GetStoredProcCommand(proc);
            AttachParameters(cmd, cmdParms);
            cmd.CommandTimeout = _commandTimeout;
            return _db.ExecuteReader(cmd);
        }

        private void AttachParameters(DbCommand cmd, IEnumerable<object> parms)
        {
            if (parms == null) return;
            var enumerable = parms as object[] ?? parms.ToArray();
            foreach (var param in enumerable.Cast<SqlParameter>())
                if (param.Value is DataTable)
                    ((SqlCommand)cmd).Parameters.AddWithValue(param.ParameterName, param.Value);
                else
                    switch (param.Direction)
                    {
                        case ParameterDirection.Input:
                            _db.AddInParameter(cmd, param.ParameterName, param.DbType, param.Value);
                            break;
                        case ParameterDirection.ReturnValue:
                            _db.AddParameter(cmd, param.ParameterName, param.DbType, param.Direction, null,
                                DataRowVersion.Default, param.Value);
                            break;
                        case ParameterDirection.InputOutput:
                            _db.AddParameter(cmd, param.ParameterName, param.DbType, param.Direction, null,
                                DataRowVersion.Default, param.Value);
                            break;
                        default:
                            if (param.Size > 0)
                                _db.AddOutParameter(cmd, param.ParameterName, param.DbType, param.Size);
                            else
                                _db.AddOutParameter(cmd, param.ParameterName, param.DbType, -1);
                            break;
                    }
        }



    }
}
