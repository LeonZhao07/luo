﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private readonly BaseDataAccess _baseDataAccess;
        public Form1()
        {
            _baseDataAccess = new BaseDataAccess("MyApp");
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            var text = textBox1.Text;
            //search data from DB
            List<User> users = new List<User>();
            using (var reader = _baseDataAccess.ExecuteReader("[dbo].[GetUserOrganizationByEmailId]"
                , CreateParameter("@pEmailId", SqlDbType.VarChar, text)))
            {
                while (reader.Read())
                {
                    users.Add(new User()
                    {
                        UserDetailKey = Convert.ToInt64(reader["UserDetailKey"]),
                        RoleId = reader["RoleId"].ToString().Trim()
                    });
                }
            }

            foreach (var user in users)
            {
                dataGridView1.Rows.Add(user.UserDetailKey, text, "test");
            }
            
        }

        private void connectivityBtn_Click(object sender, EventArgs e)
        {
            //check connectivity
            //maybe search data from DB
        }

        protected object CreateParameter(string paramName, SqlDbType dbType, object value,
            ParameterDirection direction = ParameterDirection.Input)
        {
            var sqlParam = new SqlParameter(paramName, dbType) { Direction = direction };
            if (value == null)
            {
                sqlParam.IsNullable = true;
                sqlParam.Value = DBNull.Value;
            }
            else
            {
                sqlParam.Value = value;
            }
            return sqlParam;
        }


        /// <summary>
        /// User Information
        /// </summary>
        public class User
        {
            /// <summary>
            /// Gets or sets the primary email.
            /// </summary>
            /// <value>
            /// The primary email.
            /// </value>
            public string Email { get; set; }
            /// <summary>
            /// Gets or sets the role identifier.
            /// </summary>
            /// <value>
            /// The role identifier.
            /// </value>
            public string RoleId { get; set; }
            /// <summary>
            /// Gets or sets the organizations.
            /// </summary>
            /// <value>
            /// The organizations.
            /// </value>
            public List<string> Organizations { get; set; } = new List<string>();

            /// <summary>
            /// Gets or sets the user detail key.
            /// </summary>
            /// <value>
            /// The user detail key.
            /// </value>
            public long UserDetailKey { get; set; }

            /// <summary>
            /// Gets or sets the role key.
            /// </summary>
            /// <value>
            /// The role key.
            /// </value>
            public long RoleKey { get; set; }

            /// <summary>
            /// Gets or sets the user status key.
            /// </summary>
            /// <value>
            /// The user status key.
            /// </value>
            public long UserStatusKey { get; set; }
        }

    }
}
